-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2022 at 01:14 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mahasiswa`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ambil_pelajaran`
--

CREATE TABLE `tbl_ambil_pelajaran` (
  `id_ambil` int(11) NOT NULL,
  `id_mahasiswa` int(6) NOT NULL,
  `id_pelajaran` int(5) NOT NULL,
  `id_pengajar` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jurusan`
--

CREATE TABLE `tbl_jurusan` (
  `id` int(11) NOT NULL,
  `jurusan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_jurusan`
--

INSERT INTO `tbl_jurusan` (`id`, `jurusan`) VALUES
(1, 'Teknik Informatika'),
(2, '\r\nTeknik Mesin'),
(3, 'Management'),
(4, 'Akutansi'),
(5, 'Teknik Lingkungan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tanggal_join` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `nama`, `gambar`, `email`, `password`, `tanggal_join`) VALUES
(3, 'agus', 'default.jpg', 'agus@gmail.com', '$2y$10$.6aqZ9u.KVXY8jNSj2yLr.o2hBa8Ix2U4HyOTXunKqBF3eHJPB8GC', '2020-04-20'),
(6, 'david', 'default.jpg', 'david@gmail.com', '$2y$10$CcZAP7FQOhslIR5ABOq.ce0yELBnVYDg8h1a6mcRS5.uXPxV/roC.', '2020-04-22'),
(7, 'firentus agustone', 'default.jpg', 'firentus@gmail.com', '$2y$10$GyMBKbMHpUfoqHN.3To3qOOolzsLiewMK1AJLSUONjY6fZAdkOQdu', '2020-04-23'),
(8, 'dono', 'default.jpg', 'dono@gmail.com', '$2y$10$o4oFohlruw7OkwxdK4eLBOtIKW41kdyxt/AAL9hNxN9NbtucfooJe', '2020-04-23');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mahasiswa`
--

CREATE TABLE `tbl_mahasiswa` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nrp` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `jurusan` varchar(255) NOT NULL,
  `angkatan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mahasiswa`
--

INSERT INTO `tbl_mahasiswa` (`id`, `nama`, `nrp`, `email`, `jurusan`, `angkatan`) VALUES
(17, 'agus', 311810099, 'firentua@gmail.com', '1', '2020'),
(18, 'fahri', 311819900, 'fahri@gmail.com', '\r\n2', '2020'),
(19, 'tina', 1181997777, 'tina@gmail.com', '3', '2021'),
(20, 'dayu', 211113, 'dayu@gmail.com', '4', '2021'),
(21, 'nina', 211121212, 'nina@gmail.com', '5', '2021'),
(22, 'susi', 2147483647, 'susi@gmail.com', '1', '2020'),
(23, 'ega', 311171888, 'ega@gmail.com', '2', '2020'),
(24, 'lala', 1111171888, 'lala@gmail.com', '2', '2021');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pelajaran`
--

CREATE TABLE `tbl_pelajaran` (
  `id` int(11) NOT NULL,
  `pelajaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pelajaran`
--

INSERT INTO `tbl_pelajaran` (`id`, `pelajaran`) VALUES
(1, 'Bahasa Inggris'),
(2, 'Matematika'),
(3, 'Bahasa Jepang'),
(4, 'Pemograman'),
(5, 'Desain Grafis'),
(6, 'Jaringan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengajar`
--

CREATE TABLE `tbl_pengajar` (
  `id_pengajar` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nip` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pelajaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengajar`
--

INSERT INTO `tbl_pengajar` (`id_pengajar`, `nama`, `nip`, `email`, `pelajaran`) VALUES
(2, 'dodi', 118199999, 'dodo@gmail.com', '1'),
(3, 'sugih', 311819999, 'sugih@gmail.com', '2'),
(4, 'david', 118199977, 'david@gmail.com', '3'),
(5, 'dikdik', 2147483647, 'didik@gmail.com', '4'),
(6, 'dani', 33222222, 'dani@gmail.com', '5'),
(7, 'diki', 3322223, 'diki@gmail.com', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role`
--

CREATE TABLE `tbl_role` (
  `id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_role`
--

INSERT INTO `tbl_role` (`id`, `role`) VALUES
(1, 'admin'),
(2, 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_ambil_pelajaran`
--
ALTER TABLE `tbl_ambil_pelajaran`
  ADD PRIMARY KEY (`id_ambil`);

--
-- Indexes for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pelajaran`
--
ALTER TABLE `tbl_pelajaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pengajar`
--
ALTER TABLE `tbl_pengajar`
  ADD PRIMARY KEY (`id_pengajar`);

--
-- Indexes for table `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_ambil_pelajaran`
--
ALTER TABLE `tbl_ambil_pelajaran`
  MODIFY `id_ambil` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_pelajaran`
--
ALTER TABLE `tbl_pelajaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_pengajar`
--
ALTER TABLE `tbl_pengajar`
  MODIFY `id_pengajar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
