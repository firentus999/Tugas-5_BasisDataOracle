const flashData = $('.flash-data').data('flashdata'); //ambil data dari flashdata

if (flashData) {
	Swal.fire({
		title: 'Data',
		text : 'Berhasil ' + flashData,
		icon : 'success'
	});
}


$(document).ready(function() {
    $('#example').DataTable();
} );