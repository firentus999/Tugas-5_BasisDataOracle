<?php


/**
 * 
 */
class Model_mahasiswa extends CI_Model
{
	
	public function getAllMahasiswa()
	{
		return $this->db->get('tbl_mahasiswa')->result();
	}

	public function getjurusan($jurusan,$keyword)
	{
		if ($keyword) {
			$this->db->like('nama',$keyword);
		}

		$this->db->select('*');
      	$this->db->from('tbl_jurusan');
      	$this->db->join('tbl_mahasiswa','tbl_mahasiswa.jurusan = tbl_jurusan.id_jurusan');
      	$this->db->where('jurusan',$jurusan);      
      	$query = $this->db->get();
      	return $query;
	}


	public function ADD()
	{
		$data = [
					"role" => 2,
					"nama" => $this->input->post('nama',true),
					"nrp" => $this->input->post('nrp',true),
					"email" => $this->input->post('email',true),
					"jurusan" => $this->input->post('jurusan',true)
				];

		return $this->db->insert('tbl_mahasiswa', $data);
	}

	public function ubah($id)
	{
		return $this->db->get_where('tbl_mahasiswa' ,['id' => $id])->row();

	}

	public function UPDATE()
	{
		$data = [
					"nama" => $this->input->post('nama',true),
					"nrp" => $this->input->post('nrp',true),
					"email" => $this->input->post('email',true),
					"jurusan" => $this->input->post('jurusan',true)
				];

		$this->db->where('id',$this->input->post('id'));
		$this->db->update('tbl_mahasiswa', $data);
	}

	public function DELETE($id)
	{
		return $this->db->delete('tbl_mahasiswa',['id' => $id]);
	}
}