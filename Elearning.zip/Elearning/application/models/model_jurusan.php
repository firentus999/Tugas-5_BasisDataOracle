<?php

/**
 * 
 */
class Model_jurusan extends CI_Model
{
	
	function getAllJurusan()
	{
		return $this->db->get('tbl_jurusan')->result();
	}
}