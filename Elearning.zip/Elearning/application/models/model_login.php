<?php

/**
 * 
 */
class Model_login extends CI_Model
{
	
	public function registrasi()
	{
		$data = [
					'id' =>'',
					'role' => $this->input->post('role'),
					'nama' => $this->input->post('nama'),
					'gambar' => 'default.jpg',
					'email' => $this->input->post('email'),
					'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
					'tanggal_join' => date('Y-m-d'),
		];

		$this->db->insert('tbl_login',$data);
	}

}