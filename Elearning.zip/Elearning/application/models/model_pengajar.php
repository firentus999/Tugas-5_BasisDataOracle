<?php

/**
 * 
 */
class Model_pengajar extends CI_Model
{
	public function getPengajar()
	{
		return $this->db->get('tbl_pengajar')->result();
	}
	
	public function getAllPengajar($limit,$start,$keyword=NULL)
	{
		if ($keyword) {
			$this->db->like('nama',$keyword);
		}

		$this->db->select('*');
		$this->db->from('tbl_pengajar');
		$this->db->join('tbl_pelajaran', 'tbl_pelajaran.id = tbl_pengajar.pelajaran');
		$query = $this->db->get()->result_array();

		return $query;
	}

	public function ADD()
	{
		$data = [
					"role" => 2,
					"nama" => $this->input->post('nama',true),
					"nip" => $this->input->post('nip',true),
					"email" => $this->input->post('email',true),
					"pelajaran" => $this->input->post('pelajaran',true)
				];

		return $this->db->insert('tbl_pengajar', $data);
	}

	public function ubah($id)
	{
		return $this->db->get_where('tbl_pengajar' ,['id_pengajar' => $id])->row();

	}

	public function UPDATE()
	{
		$data = [
					"nama" => $this->input->post('nama',true),
					"nip" => $this->input->post('nip',true),
					"email" => $this->input->post('email',true),
					"pelajaran" => $this->input->post('pelajaran',true)
				];

		$this->db->where('id',$this->input->post('id'));
		$this->db->update('tbl_pengajar', $data);
	}

	public function DELETE($id)
	{
		return $this->db->delete('tbl_pengajar',['id_pengajar' => $id]);
	}
}
