<?php

/**
 * 
 */
class Model_pelajaran extends CI_Model
{
	
	public function getAllPelajaran()
	{
		return $this->db->get('tbl_pelajaran')->result();
	}

	public function materi($pelajaran)
	{
		$this->db->select('*');
      	$this->db->from('tbl_pelajaran');
      	$this->db->join('tbl_materi','tbl_materi.mata_kuliah = tbl_pelajaran.id');
      	$this->db->where('pelajaran',$pelajaran);      
      	$query = $this->db->get();
      	return $query;
	}

	public function ambil_matakuliah()
	{
		$this->db->select('*');
      	$this->db->from('tbl_pengajar');
      	$this->db->join('tbl_ambil_pelajaran','tbl_ambil_pelajaran.id_dosen = tbl_pengajar.id_pengajar');     
      	$query = $this->db->get();
      	return $query;
	}
}