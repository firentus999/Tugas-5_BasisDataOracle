<table class="table table bordered table-hover table-striped text-center">
	<thead>
		<tr>
			<th>NO</th>
			<th>NAMA</th>
			<th>NRP</th>
			<th>EMAIL</th>
			<th>JURUSAN</th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; ?>
		<?php foreach ($mahasiswa as $m):?>
		<tr>
			<td><?=$no++; ?></td>
			<td><?= $m['nama']; ?></td>
			<td><?= $m['nrp']; ?></td>
			<td><?= $m['email']; ?></td>
			<td><?= $m['jurusan'] ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>
<td><a href="<?= site_url('mahasiswa/mahasiswa/cek_mahasiswa') ?>" class="badge badge-warning">Kembali</a></td>