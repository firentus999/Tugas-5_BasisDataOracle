<div class="row " style="margin-top: 70px;">
	<div class="col-md-4"></div>
		<div class="col-md-4">
			<div class="card">
				<?php if($this->session->flashdata('success')):?>
				 	<div class="flash-data" data-flashdata=" <?= $this->session->flashdata('success'); ?>"></div>
				<?php endif; ?>
			 <div class="card-header bg-light"><i class="fas fa-bars"></i> Halaman login</div>
			  <div class="card-body">
			    <h5 class="card-title text-center mb-5">Silahkan Login!</h5>
			   	<form method="post" action="<?= site_url('login/login') ?>">
				  <div class="input-group mb-4">
				  	<div class="input-group-prepend">
					    <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
					    <input type="text" class="form-control" placeholder="Enter email" name="email" autocomplete="off" value="<?= set_value('email') ?>" style="width: 300px;">
					  </div>
				    <small id="emailHelp" class="form-text text-danger"><?= form_error('email') ?></small>
				  </div>
				  <div class="input-group mb-5">
				  	<div class="input-group-prepend">
					    <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
					    <input type="password" class="form-control" placeholder="Password" name="password" style="width: 300px;">
					  </div>
				    <small id="emailHelp" class="form-text text-danger"><?= form_error('password')?></small>
				  </div>
				  <button type="submit" class="btn btn-primary" style="width: 100%; margin-bottom: 10px;">Sign Here</button>
				</form>
			  </div>
			</div>
			 <?php if($this->session->flashdata('wrong')):?>
				 	<?= $this->session->flashdata('wrong'); ?>
				<?php endif; ?>
		</div>
	<div class="col-md-4"></div>
</div>
