<div class="row mt-4">
  <div class="col-md-4"></div>
  <div class="col-md-4">
    <div class="card">
      <div class="card-header bg-light">
        <i class="fas fa-bars"></i> Menu Registrasi
      </div>
      <div class="card-body">
        <h5 class="card-title text-center">Silahkan Registrasi !</h5><br>
        <form method="post" action="<?= site_url('login/registrasi') ?>">
          <div class="input-group mb-4">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
              <input type="text" class="form-control" placeholder="Masukan Nama Anda" name="nama" autocomplete="off" autofocus value="<?= set_value('nama') ?>">
            </div>
              <small id="emailHelp" class="form-text text-danger"><?= form_error('nama') ?></small>
          </div>
          <div class="input-group mb-4">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
               <input type="text" class="form-control" placeholder="Enter email" name="email" autocomplete="off" value="<?= set_value('email') ?>">
            </div>
             <small id="emailHelp" class="form-text text-danger"><?= form_error('email') ?></small>
          </div>
          <div class="input-group mb-4">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
              <input type="password" class="form-control" placeholder="Password" name="password1" autocomplete="off">
            </div>
            <small id="emailHelp" class="form-text text-danger"><?= form_error('password1') ?></small>
          </div>
           <div class="input-group mb-5">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
               <input type="password" class="form-control" placeholder="Ulangi Password" name="password2" autocomplete="off">
            </div>
            <small id="emailHelp" class="form-text text-danger"><?= form_error('password2') ?></small>
          </div>
          <button type="submit" class="btn btn-primary" style="width: 100%;">Submit Akun</button>
        </form>
         <a href="<?= site_url('login/login') ?>" class="text-primary btn btn-white" style="width: 100%;">Back To Login</a>
      </div>
    </div>
  </div>
  <div class="col-md-4"></div>
</div>

