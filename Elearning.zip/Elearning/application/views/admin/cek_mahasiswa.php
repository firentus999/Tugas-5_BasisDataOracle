<div class="container-fluid">
	<div class="row mt-4">
		<div class="col-lg-6">
			<div class="card">
			  <div class="card-header">
			   Data Mahasiswa Pelita Bangsa
			  </div>
			  <?php if($this->session->flashdata('success')):?>
			 <div class="flash-data" data-flashdata=" <?= $this->session->flashdata('success'); ?>"></div>
			<?php endif; ?>

			  <div class="card-body">
			    <h5 class="card-title">Mahasiswa Akutansi</h5>
			    <a href="" class="btn btn-primary mb-4"  data-toggle="modal" data-target="#exampleModal"><i class="fas fa-user-plus"></i> Tambah Data Mahasiswa</a>

			    	<form  method="post" action="">
				      <div class="input-group mb-3">
						  <input type="search" class="form-control" placeholder="Masukan Keyword" aria-label="Recipient's username" aria-describedby="basic-addon2" name="keyword" autocomplete="off">
						  <div class="input-group-append">
						    <input class="btn btn-outline-secondary" type="submit" name="cari"></input>
						  </div>
						</div>
				    </form>
							   
			    <table class="table table bordered table-hover table-striped text-center">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>JURUSAN</th>
			    			<th>AKSI</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			  			<tr>
			  				<?php if (empty($mahasiswa)):?>
			  					<td colspan="4">
			  						<div class="alert alert-danger" role="alert">
								  		Data Not Found!
									</div>
								</td>
							<?php endif; ?>
			  			</tr>
			  			<?php $start=1; ?>
			    			<?php foreach ($mahasiswa as $value):?>
			    			<tr>
			    				<td><?=$start++; ?></td>
			    				<td><?= $value['nama'] ?></td>
			    				<td><?= $value['kejuruan'] ?></td>
			    				<td colspan="3">
			    					<a href="<?= site_url('mahasiswa/mahasiswa/detailMahasiswa/'.$value['id']) ?>" class="badge badge-primary">Detail</a>
			    					<a href="<?= site_url('mahasiswa/mahasiswa/ubahMahasiswa/' .$value['id']) ?>" class="badge badge-success">Ubah</a>
			    					<a href="<?= site_url('mahasiswa/mahasiswa/hapusMahasiswa/' .$value['id']) ?>" class="badge badge-danger">Hapus</a>
			    				</td>
			    			</tr>
			    			<?php endforeach; ?>
			    		</tbody>
			    </table>
			    <section align="right"><?php echo $this->pagination->create_links(); ?></section>
			  </div>
			</div>
		</div>
<div class="col-md-2 text-dark ml-3">
			<div class="card mr-3" style="width: 16rem;">
				<div class="card-header">
					Mahasiswa
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-user-graduate"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Semua Mahasiswa</h5>
			    <div class="display-4 ">
			    	<?= $Mahasiswa; ?>
			    </div>
			    <a href="<?= site_url('home/home/allMahasiswa') ?>" > <i class="fas fa-angle-double-right text-success"> Lihat Detail Mahasiswa</i></a>
			  </div>
			</div>
		</div>
		<div class="col-md-2 text-dark ml-5">
			<div class="card ml-3" style="width: 16rem;">
				<div class="card-header">
					Pengajar
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-chalkboard-teacher"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Semua Dosen</h5>
			    <div class="display-4">
			    	<?= $Pengajar; ?>
			    </div>
			    <a href="<?= site_url('home/home/allPengajar') ?>" ><i class="fas fa-angle-double-right text-success"> Lihat Detail Dosen</i></a>
			  </div>
			</div>
		</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-user-graduate"></i> Tambah Data Mahasiswa</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="">
        	<div class="form-group mb-3">
        		<input type="text" name="nama" class="form-control" placeholder="Usernama Anda" required autocomplete="off">
        		
        	</div>
        	<div class="form-group mb-3">
        		<input type="number" name="nrp" class="form-control" placeholder="Nrp Anda"required autocomplete="off">
        		
        	</div>
        	<div class="form-group mb-3">
        		<input type="email" name="email" class="form-control" placeholder="Email Anda" required autocomplete="off">
        		<small  class="form-text text-danger"><?= form_error('email'); ?></small>
        			
        	</div>
        	<div class="form-group mb-3">
        		<select class="custom-select" name="jurusan">
				  <?php foreach ($jurusan as $value):?>
				  	<option value="<?= $value->jurusan ?>"><?= $value->jurusan ?></option>

				  <?php endforeach; ?>
				</select>
        	</div>
        	<button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>

