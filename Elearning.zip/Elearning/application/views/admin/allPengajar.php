<div class="container-fluid">
	<div class="col-md-10">
		<div class="card">
		  <div class="card-header">
		    Data Keseluruhan Dosen Pelita Bangsa
		  </div>
		  <div class="card-body">
		    <h5 class="card-title">Pengajar</h5>
		    <table class="table table bordered table-hover table-striped text-center" id="example">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>NIP</th>
			    			<th>EMAIL</th>
			    			<th>PELAJARAN</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			    			<?php $no=1; ?>
			    			<?php foreach ($allPengajar as $value): ?>
			    			<tr>
			    				<td><?=$no++; ?></td>
			    				<td><?= $value->nama ?></td>
			    				<td><?= $value->nip ?></td>
			    				<td><?= $value->email ?></td>
			    				<td><?= $value->pelajaran ?></td>
			    			</tr>
			    		<?php endforeach; ?>
			    		</tbody>
			    </table>
			    <td><a href="<?= site_url('pengajar/pengajar') ?>" class="badge badge-warning">Halaman Pengajar</a></td>
		  </div>
		</div>
	</div>	
</div>