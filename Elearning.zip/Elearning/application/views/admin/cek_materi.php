<div class="container-fluid">
	<?php if ($this->session->flashdata('success')):?>
    <div class="flash-data" data-flashdata='<?= $this->session->flashdata('success'); ?>'></div>
  <?php endif; ?>

 <?php if ($cek1['id_pelajaran']==$this->uri->segment(4)):?>

	<div class="col-md-10 mt-4">
		<div class="card">
		  <div class="card-header">
		    Materi Kuliah <?= $this->uri->segment(4) ?>
		  </div>
		  <div class="card-body">
		  	<?php if ($user['role']==3):?>
                  <a href="" class="btn btn-primary mb-2" data-toggle="modal" data-target="#exampleModal"><i class="fab fa-leanpub"></i> Tambah Materi</a>
              <?php endif; ?>
		    <table class="table table bordered table-hover table-striped text-center" id="example">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>MATERI</th>
			    			<th>TANGGAL</th>
			    			<th>AKSI</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			    			<?php $no=1; ?>
			    			<?php foreach ($materi as $m): ?>
			    			<tr>
                  <?php if (empty($cek1['id_pelajaran']==$this->uri->segment(4))):?>
                  <td colspan="4">
                    <div class="alert alert-danger" role="alert">
                      Data Not Found!
                  </div>
                </td>
              <?php endif; ?>

			    				<td><?=$no++; ?></td>
			    				<td><?= $m['dosen'] ?></td>
			    				<td><?= $m['materi'] ?></td>
			    				<td><?= $m['tanggal'] ?></td>
                  <?php if ($this->session->userdata('role')==1):?>
                      <td><a href="<?= site_url('materi/materi/hapus_materi/').$m['id_materi'] ?>" id="hapus" data-toggle='tooltip' data-placement='top' title='Hapus'><i class="fas fa-trash-alt"></i></a></td>
                  <?php endif; ?>
                  <?php if ($this->session->userdata('role')==3):?>
                      <td><a href="<?= site_url('materi/materi/hapus_materi/').$m['id_materi'] ?>" id="hapus" data-toggle='tooltip' data-placement='top' title='Hapus'><i class="fas fa-trash-alt"></i></a></td>
                  <?php endif; ?>
                  <td>
                        <a href="<?= site_url('materi/materi/lakukan_download/'.$m['materi']) ?>" id="materi" data-toggle='tooltip' data-placement='top' title='Download Materi'><i class="fas fa-download"></i>
                    </a></td>

			    			</tr>
			    		<?php endforeach; ?>
			    		</tbody>
			    </table>
			    <td><a href="<?= site_url('pengajar/pengajar') ?>" class="badge badge-warning">Halaman Pengajar</a></td>
		  </div>
		</div>
	</div>	

<?php endif; ?>


  <?php if ($this->session->userdata('role')==1):?>

    <div class="col-md-10 mt-4">
    <div class="card">
      <div class="card-header">
        Materi Kuliah <?= $this->uri->segment(4) ?>
      </div>
      <div class="card-body">
        <?php if ($user['role']==3):?>
                  <a href="" class="btn btn-primary mb-2" data-toggle="modal" data-target="#exampleModal"><i class="fab fa-leanpub"></i> Tambah Materi</a>
              <?php endif; ?>
        <table class="table table bordered table-hover table-striped text-center" id="example">
            <thead>
              <tr>
                <th>NO</th>
                <th>NAMA</th>
                <th>MATERI</th>
                <th>TANGGAL</th>
                <th>AKSI</th>
              </tr>
            </thead>
              <tbody>
                <?php $no=1; ?>
                <?php foreach ($materi as $m): ?>
                <tr>
                  <td><?=$no++; ?></td>
                  <td><?= $m['dosen'] ?></td>
                  <td><?= $m['materi'] ?></td>
                  <td><?= $m['tanggal'] ?></td>
                          <td><a href="<?= site_url('materi/materi/hapus_materi/').$m['id_materi'] ?>" id="hapus" data-toggle='tooltip' data-placement='top' title='Hapus'><i class="fas fa-trash-alt"></i></a></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
          </table>
          <td><a href="<?= site_url('pengajar/pengajar') ?>" class="badge badge-warning">Halaman Pengajar</a></td>
      </div>
    </div>
  </div>

  <?php endif; ?>


</div>




<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Upload Materi</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <div class="card">
              <div class="card-header bg-light">
                <i class="fas fa-bars"></i> Menu Materi
              </div>
              <div class="card-body">
                <h5 class="card-title text-center">Silahkan Tambah Materi !</h5><br>
                <?php echo form_open_multipart('materi/materi/tambah_materi');?>
                <input type="hidden" class="form-control" name="nama" autocomplete="off" value="<?= $user['nama'] ?>" >
                 <label>Mata Kuliah :</label><br>
                 <div class="input-group mb-4" style="width:235px">
                    <select class="custom-select" id="inputGroupSelect01" name="pelajaran" required>
                      <option selected>...</option>
                      <?php foreach ($pelajaran as $p):?>
                      	<option value="<?= $p['id'] ?>"><?= $p['pelajaran'] ?></option>
                      <?php endforeach; ?>	
                    </select>
                    <small id="emailHelp" class="form-text text-danger"><?= form_error('pelajaran') ?></small>
                  </div>
                  <label>Materi :</label>
                   <div class="input-group mb-5">
                     <input type="file" class="form-control" name="file" autocomplete="off" required>
                    <small id="emailHelp" class="form-text text-danger"><?= form_error('file') ?></small>
                  </div>
                  <button type="submit" class="btn btn-primary" style="width: 100%;">Submit Materi</button>
                </form>
                <br>
              </div>
            </div>
      </div>