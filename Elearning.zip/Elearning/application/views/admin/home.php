<div class="container-fluid">
  <div class="card mt-2">
  <h5 class="card-header"><i class="fas fa-tachometer-alt"></i> DASHBOARD</h5>
  <div class="card-body">
    <div class="row mt-2">
  <div class="col-md-12">
    <div class="title text-center"><h2><strong>" Aplikasi Elearning Mahasiswa UPB "</strong></h2></div>
  </div>
</div><hr class="divider">
<div class="row mt-5">
  <?php if ($this->session->flashdata('success')):?>
    <div class="flash-data" data-flashdata='<?= $this->session->flashdata('success'); ?>'></div>
  <?php endif; ?>
  <div class="col-md-6">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner " style="height: 50%;">
        <div class="carousel-item active">
          <img class="d-block w-100" src="<?= site_url('assets/img/logo.png') ?>" alt="First slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="<?= site_url('assets/img/gedung1.jpg') ?>" alt="Second slide">
        </div>
        <div class="carousel-item">
          <img class="d-block w-100" src="<?= site_url('assets/img/gedung2.png') ?>." alt="Third slide">
        </div>
      </div>
    </div>
  </div>
      <div class="col-md-3">
          <div class="card">
            <div class="card-header">
            <strong><p class="card-text mb-3 "><span><i class="fas fa-user"></i> Selamat Datang <strong><?= $user['nama'] ?> </strong></span></strong>
            </div>
            <div class="card-body">
              <?php if ($user['role']==1):?>
                  <a href="<?= site_url('login/registrasi') ?>" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-user-plus"></i> Tambah Data Akun</a>
              <?php endif; ?>
              <br><br>
              <a href="<?= site_url('login/login/logout') ?>" data-toggle="tooltip" data-placement="top" title="logout"><i class="fas fa-sign-out-alt text-dark"></i></a>
            </div>
          </div>
        </div>     
      </div>
      <div class="col-md-1"></div>
</div>
  </div>
</div>

</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Akun</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <div class="card">
              <div class="card-header bg-light">
                <i class="fas fa-bars"></i> Menu Registrasi
              </div>
              <div class="card-body">
                <h5 class="card-title text-center">Silahkan Registrasi !</h5><br>
                <form method="post" action="<?= site_url('login/registrasi') ?>">
                  <div class="input-group mb-4" style="width:235px">
                    <select class="custom-select" id="inputGroupSelect01" name="role">
                      <option selected>Role</option>
                      <option value="1">Admin</option>
                      <option value="2">Mahasiswa</option>
                      <option value="3">Pengajar</option>
                    </select>
                  </div>
                  <div class="input-group mb-4">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
                      <input type="text" class="form-control" placeholder="Masukan Nama Anda" name="nama" autocomplete="off" autofocus>
                    </div>
                      <small id="emailHelp" class="form-text text-danger"><?= form_error('nama') ?></small>
                  </div>
                  <div class="input-group mb-4">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
                       <input type="text" class="form-control" placeholder="Enter email" name="email" autocomplete="off">
                    </div>
                     <small id="emailHelp" class="form-text text-danger"><?= form_error('email') ?></small>
                  </div>
                  <div class="input-group mb-4">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
                      <input type="password" class="form-control" placeholder="Password" name="password1" autocomplete="off">
                    </div>
                    <small id="emailHelp" class="form-text text-danger"><?= form_error('password1') ?></small>
                  </div>
                   <div class="input-group mb-5">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="basic-addon1"><i class="fas fa-lock"></i></span>
                       <input type="password" class="form-control" placeholder="Ulangi Password" name="password2" autocomplete="off">
                    </div>
                    <small id="emailHelp" class="form-text text-danger"><?= form_error('password2') ?></small>
                  </div>
                  <button type="submit" class="btn btn-primary" style="width: 100%;">Submit Akun</button>
                </form>
                <br>
              </div>
            </div>
      </div>