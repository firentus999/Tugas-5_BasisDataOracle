<div class="container-fluid">
	<h3 class="mt-3 mb-4"><i class="fas fa-user-graduate"></i>Data Mata Kuliah Pelita Bangsa</h3>

	<?php if($this->session->flashdata('success')):?>
		<div class="flash-data" data-flashdata=" <?= $this->session->flashdata('success'); ?>"></div>
	<?php endif; ?>	

  <a href="" class="btn btn-primary mb-2" data-toggle="modal" data-target="#exampleModal"><i class="fab fa-leanpub"></i> Ambil Mata Kuliah</a>		    
			    
		<div class="row">

            <!-- Earnings (Monthly) Card Example -->
            <?php foreach ($pelajaran as $p ):?>

            <div class="col-xl-3 col-md-6 mb-4">
              <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-dark text-uppercase mb-1"><?= $p['pelajaran'] ?></div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800"><a href="<?= site_url('materi/materi/cek_materi/'.$p['pelajaran']) ?>">Cek Materi</a></div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?> 

        </div>
        <?php if ($cek['role'] == 1):?>
          <a href="<?= site_url('materi/materi/mahasiswa_materi') ?>" class="btn btn-success mb-2"><i class="fab fa-leanpub"></i> Cek Mahasiswa</a>
        <?php endif; ?> 

        <?php if ($cek['role'] == 3):?>
          <a href="<?= site_url('materi/materi/mahasiswa_materi') ?>" class="btn btn-success mb-2"><i class="fab fa-leanpub"></i> Cek Mahasiswa</a>
        <?php endif; ?> 
			    
</div>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ambil Mata Kuliah</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <div class="card">
              <div class="card-header bg-light">
                <i class="fas fa-bars"></i> Mata Kuliah
              </div>
              <div class="card-body">
                <h5 class="card-title text-center">Silahkan Mata Kuliah !</h5><br>
                <form method="POST" action="<?= site_url('materi/materi/ambil_materi'); ?>">
                <input type="hidden" class="form-control" name="nama" autocomplete="off" value="<?= $user['nama'] ?>" >
                 <label>Mata Kuliah :</label><br>
                 <div class="input-group mb-4" style="width:235px">
                    <select class="custom-select" id="inputGroupSelect01" name="pelajaran" required>
                      <option selected>...</option>
                      <?php foreach ($pelajaran as $p):?>
                        <option value="<?= $p['pelajaran'] ?>"><?= $p['pelajaran'] ?></option>
                      <?php endforeach; ?>  
                    </select>
                    <small id="emailHelp" class="form-text text-danger"><?= form_error('pelajaran') ?></small>
                  </div>
                  <button type="submit" class="btn btn-primary" style="width: 100%;">Submit</button>
                </form>
                <br>
              </div>
            </div>
      </div>

