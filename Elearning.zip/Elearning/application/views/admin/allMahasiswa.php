<div class="container-fluid">
	<div class="col-md-10 mt-3">
		<div class="card">
		  <div class="card-header">
		    Data Keseluruhan Mahasiswa Pelita Bangsa
		  </div>
		  <div class="card-body">
		    <h5 class="card-title">Mahasiswa</h5>
		 		    <table class="table table bordered table-hover table-striped text-center" id="example">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>NRP</th>
			    			<th>EMAIL</th>
			    			<th>JURUSAN</th>
			    			<th>ANGKATAN</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			    			<?php $no=1; ?>
			    			<?php foreach ($allMahasiswa as $value):?>
			    			<tr>
			    				<td><?=$no++; ?></td>
			    				<td><?= $value->nama ?></td>
			    				<td><?= $value->nrp ?></td>
			    				<td><?= $value->email ?></td>
			    				<td><?= $value->jurusan ?></td>
			    				<td><?= $value->angkatan ?></td>
			    			</tr>
			    		<?php endforeach; ?>
			    		</tbody>
			    </table>
			    <a href="<?= site_url('pengajar/pengajar') ?>" class="badge badge-primary">page Pengajar <i class="fas fa-angle-double-right"></i></a>

		  </div>
		</div>
	</div>	
</div>