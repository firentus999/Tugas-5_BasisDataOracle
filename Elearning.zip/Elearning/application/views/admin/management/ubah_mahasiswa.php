<div class="container-fluid">
	<div class="row mt-5">
		<div class="col-lg-6">
			<div class="card">
			  <div class="card-header">
			   Data Mahasiswa Pelita Bangsa
			  </div>
			  <div class="card-body">
			    <h5 class="card-title"> Ubah Data Mahasiswa</h5>
			    <form method="post" action="<?= site_url('mahasiswa/management/mahasiswa/updateMahasiswa') ?>">
			    	<input type="hidden" name="id" value="<?= $u_Mahasiswa->id  ?>">
		        	<div class="input-group mb-3">
		        		<input type="text" name="nama" class="form-control" placeholder="Usernama Anda" value="<?= $u_Mahasiswa->nama ?>">	
		        	</div>
		        	<div class="input-group mb-3">
		        		<input type="text" name="nrp" class="form-control" placeholder="Nrp Anda" value="<?= $u_Mahasiswa->nrp ?>">	
		        	</div>
		        	<div class="input-group mb-3">
		        		<input type="email" name="email" class="form-control" placeholder="Email Anda" value="<?= $u_Mahasiswa->email ?>">	
		        	</div>
		        	<div class="input-group mb-3">
		        		<select class="custom-select" name="jurusan">
		        			<?php foreach ($jurusan as $value):?>
		        			<?php if ($value->jurusan == $u_Mahasiswa->jurusan):?>
		        				<option value="<?= $value->jurusan ?>" selected>
		        					<?= $value->jurusan ?></option>
		  					<?php else:?>
		        					<option value="<?= $value->jurusan ?>">
		        						<?= $value->jurusan ?></option>
		        			<?php endif; ?>
		        		<?php endforeach; ?>
		        			  
						</select>
		        	</div>
		        	<button type="submit" class="badge badge-primary">Update</button>
		        	<a href="<?= site_url('mahasiswa/management/mahasiswa') ?>" class="badge badge-warning">Kembali</a>
		        </form>
			  </div>
			</div>
		</div>
		<div class="col-md-2 text-dark ml-2">
			<div class="card mr-3" style="width: 16rem;">
				<div class="card-header">
					Mahasiswa
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-user-graduate"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Mahasiswa</h5>
			    <div class="display-4 ">
			    	<?= $Mahasiswa; ?>
			    </div>
			  </div>
			</div>
		</div>
		<div class="col-md-2 text-dark ml-2">
			<div class="card ml-3" style="width: 16rem;">
				<div class="card-header">
					Pengajar
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-chalkboard-teacher"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Dosen</h5>
			    <div class="display-4">
			    	<?= $Pengajar; ?>
			    </div>
			  </div>
			</div>
		</div>
	</div>
</div>