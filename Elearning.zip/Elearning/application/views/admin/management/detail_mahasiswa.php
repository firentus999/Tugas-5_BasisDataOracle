<div class="container-fluid">
	<div class="row mt-5">
		<div class="col-lg-6">
			<div class="card">
			  <div class="card-header">
			   Data Mahasiswa Pelita Bangsa
			  </div>
			  <div class="card-body">
			    <h5 class="card-title">Mahasiswa Management</h5>
			    <a href="" class="btn btn-primary mb-4"  data-toggle="modal" data-target="#exampleModal">Tambah Data Mahasiswa</a>
			    <table class="table table bordered table-hover table-striped text-center">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>NRP</th>
			    			<th>EMAIL</th>
			    			<th>JURUSAN</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			    			<?php $no=1; ?>
			    			<tr>
			    				<td><?=$no++; ?></td>
			    				<td><?= $u_Mahasiswa->nama ?></td>
			    				<td><?= $u_Mahasiswa->nrp ?></td>
			    				<td><?= $u_Mahasiswa->email ?></td>
			    				<td><?= $u_Mahasiswa->jurusan ?></td>
			    			</tr>
			    		</tbody>
			    </table>
			    <td><a href="<?= site_url('mahasiswa/management/') ?>" class="badge badge-warning">Kembali</a></td>
			  </div>
			</div>
		</div>
		<div class="col-md-2 text-dark ml-2">
			<div class="card mr-3" style="width: 16rem;">
				<div class="card-header">
					Mahasiswa
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-user-graduate"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Mahasiswa</h5>
			    <div class="display-4 ">
			    	<?= $Mahasiswa; ?>
			    </div>
			  </div>
			</div>
		</div>
		<div class="col-md-2 text-dark ml-2">
			<div class="card ml-3" style="width: 16rem;">
				<div class="card-header">
					Pengajar
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-chalkboard-teacher"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Dosen</h5>
			    <div class="display-4">
			    	<?= $Pengajar; ?>
			    </div>
			  </div>
			</div>
		</div>
	</div>
</div>