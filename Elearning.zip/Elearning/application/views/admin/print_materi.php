<div class="container-fluid">
	<h3 style="text-align: center;">Data Mahasiswa</h3>
	<table class="table table bordered table-hover table-striped text-center">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA MAHASISWA</th>
			    			<th>NAMA DOSEN</th>
			    			<th>PELAJARAN</th>
			    			<th>TANGGAL</th>

			    		</tr>
			    	</thead>
			    		<tbody>
			  			<tr>
			  				<?php if (empty($ambil_matakuliah)):?>
			  					<td colspan="4">
			  						<div class="alert alert-danger" role="alert">
								  		Data Not Found!
									</div>
								</td>
							<?php endif; ?>
			  			</tr>
			    			<?php foreach ($ambil_matakuliah as $value):?>
			    			<tr>
			    				<td><?= ++$start; ?></td>
			    				<td><?= $value['mahasiswa'] ?></td>
			    				<td><?= $value['nama'] ?></td>
			    				<td><?= $value['id_pelajaran'] ?></td>
			    				<td><?= $value['tanggal'] ?></td>

			    			</tr>
			    			<?php endforeach; ?>
			    		</tbody>
			    </table>
</div>

<script type="text/javascript">
		window.print();
	</script>