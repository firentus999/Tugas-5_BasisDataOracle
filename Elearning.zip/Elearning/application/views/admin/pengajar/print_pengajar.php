<div class="container-fluid">
	<h3 style="text-align: center;">Data Pengajar</h3>
	<table class="table table bordered table-hover table-striped text-center">
			    	<thead class="bg-primary text-white">
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>PELAJARAN</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			  			<tr>
			  				<?php if (empty($pengajar)):?>
			  					<td colspan="4">
			  						<div class="alert alert-danger" role="alert">
								  		Data Not Found!
									</div>
								</td>
							<?php endif; ?>
			  			</tr>
			    			<?php foreach ($pengajar as $value):?>
			    			<tr>
			    				<td><?= ++$start; ?></td>
			    				<td><?= $value['nama']; ?></td>
			    				<td><?= $value['pelajaran']; ?></td>
			    			</tr>
			    			<?php endforeach; ?>
			    		</tbody>
			    </table>
		<script type="text/javascript">
		window.print();
	</script>
</div>