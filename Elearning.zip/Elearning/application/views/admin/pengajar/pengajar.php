<div class="container-fluid">
	<div class="row mt-3">
		<div class="col-lg-6">
			<div class="card">
			  <div class="card-header">
			   <h3 class=""><i class="fas fa-user-graduate"></i> Data Pengajar Pelita Bangsa</h3>
			  </div>
			  <?php if($this->session->flashdata('success')):?>
			 <div class="flash-data" data-flashdata=" <?= $this->session->flashdata('success'); ?>"></div>
			<?php endif; ?>

			  <div class="card-body">
			    <h5 class="card-title">Dosen Pelita Bangsa</h5>
			    <a class="btn btn-success" href="<?= site_url('pengajar/pengajar/Excel_pengajar') ?>">Export Excel</a>
			    <a class="btn btn-warning" href="<?= site_url('pengajar/pengajar/Print_pengajar') ?>">Print</a>
			    <form  method="post" action="">
				      <div class="input-group mb-3 mt-2">
						  <input type="search" class="form-control" placeholder="Masukan Keyword" aria-label="Recipient's username" aria-describedby="basic-addon2" name="keyword" autocomplete="off">
						  <div class="input-group-append">
						    <input class="btn btn-outline-secondary" type="submit" name="cari"></input>
						  </div>
						</div>
				    </form>
			    <table class="table table bordered table-hover table-striped text-center">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA</th>
			    			<th>PELAJARAN</th>
			    			<?php if (!$cek['role'] == 2):?>
			    			<th>AKSI</th>
			    		<?php endif; ?>
			    		</tr>
			    	</thead>
			    		<tbody>
			  			<tr>
			  				<?php if (empty($pengajar)):?>
			  					<td colspan="4">
			  						<div class="alert alert-danger" role="alert">
								  		Data Not Found!
									</div>
								</td>
							<?php endif; ?>
			  			</tr>
			    			<?php foreach ($pengajar as $value):?>
			    			<tr>
			    				<td><?= ++$start; ?></td>
			    				<td><?= $value['nama'] ?></td>
			    				<td><?= $value['pelajaran'] ?></td>
			    				<?php if ($cek['role'] == 1):?>
			    				<td colspan="3">
			    					
			    					<a href="<?= site_url('pengajar/pengajar/detailPengajar/'.$value['id_pengajar']) ?>" class="badge badge-primary">Detail</a>
			    					<a href="<?= site_url('pengajar/pengajar/ubahPengajar/' .$value['id_pengajar']) ?>" class="badge badge-success">Ubah</a>
			    					<a href="<?= site_url('pengajar/pengajar/hapusPengajar/' .$value['id_pengajar']) ?>" class="badge badge-danger">Hapus</a>
			    				</td>
			    				<?php endif; ?>
			    				<?php if ($cek['role'] == 3):?>
			    				<td colspan="3">
			    					
			    					<a href="<?= site_url('pengajar/pengajar/detailPengajar/'.$value['id_pengajar']) ?>" class="badge badge-primary">Detail</a>
			    					<a href="<?= site_url('pengajar/pengajar/ubahPengajar/' .$value['id_pengajar']) ?>" class="badge badge-success">Ubah</a>
			    					<a href="<?= site_url('pengajar/pengajar/hapusPengajar/' .$value['id_pengajar']) ?>" class="badge badge-danger">Hapus</a>
			    				</td>
			    				<?php endif; ?>
			    			</tr>
			    			<?php endforeach; ?>
			    		</tbody>
			    </table>
			     <section align="right"><?php echo $this->pagination->create_links(); ?></section>
			  </div>
			  <?php if ($cek['role'] == 1):?>
			  <a class="btn btn-primary mb-4"  data-toggle="modal" data-target="#exampleModal">Tambah Data Pengajar</a>
			<?php endif; ?>
			<?php if ($cek['role'] == 3):?>
			  <a class="btn btn-primary mb-4"  data-toggle="modal" data-target="#exampleModal">Tambah Data Pengajar</a>
			<?php endif; ?>
			</div>
		</div>
<div class="col-md-2 text-dark ml-3">
			<div class="card mr-3" style="width: 16rem;">
				<div class="card-header">
					Mahasiswa
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-user-graduate"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Mahasiswa</h5>
			    <div class="display-4 ">
			    	<?= $Mahasiswa; ?>
			    </div>
			    <a href="<?= site_url('home/home/allMahasiswa') ?>" > <i class="fas fa-angle-double-right text-success"> Lihat Detail</i></a>
			  </div>
			</div>
		</div>
		<div class="col-md-2 text-dark ml-5">
			<div class="card ml-2" style="width: 16rem;">
				<div class="card-header">
					Pengajar
				</div>
			  <div class="card-body">
			  	<div class="card-body-icon">
			  		<i class="fas fa-chalkboard-teacher"></i>
			  	</div>
			    <h5 class="card-title text-primary">Jumlah Dosen</h5>
			    <div class="display-4">
			    	<?= $Pengajar; ?>
			    </div>
			    <a href="<?= site_url('home/home/allPengajar') ?>" ><i class="fas fa-angle-double-right text-success"> Lihat Detail</i></a>
			  </div>
			</div>
		</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-user-graduate"></i> Tambah Data Pengajar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="">
        	<div class="form-group mb-3">
        		<input type="text" name="nama" class="form-control" placeholder="Usernama Anda"autocomplete="off">
        		<small  class="form-text text-danger"><?= form_error('nama'); ?></small>
        		
        	</div>
        	<div class="form-group mb-3">
        		<input type="number" name="nip" class="form-control" placeholder="Nip Anda" autocomplete="off">
        		<small  class="form-text text-danger"><?= form_error('nip'); ?></small>
        		
        	</div>
        	<div class="form-group mb-3">
        		<input type="email" name="email" class="form-control" placeholder="Email Anda" autocomplete="off">
        		<small  class="form-text text-danger"><?= form_error('email'); ?></small>
        			
        	</div>
        	<div class="form-group mb-3">
        		<select class="custom-select" name="pelajaran">
				  <?php foreach ($pelajaran as $value):?>
				  	<option value="<?= $value->pelajaran ?>"><?= $value->pelajaran ?></option>

				  <?php endforeach; ?>
				</select>
        	</div>
        	<button type="submit" class="btn btn-primary">Save</button>
        </form>
      </div>
    </div>
  </div>
</div>

