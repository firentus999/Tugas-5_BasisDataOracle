<div class="container-fluid">
	<div class="row mt-5">
		<div class="col-lg-6">
			<div class="card">
			  <div class="card-header">
			   Data Mahasiswa Ambil Mata Kuliah
			  </div>
			  <div class="card-body">
			  	<a class="btn btn-success mb-2" href="<?= site_url('materi/materi/Excel_mahasiswa') ?>">Export Excel</a>
			    <a class="btn btn-warning mb-2" href="<?= site_url('materi/materi/Print_mahasiswa') ?>">Print</a>
			    <table class="table table bordered table-hover table-striped text-center">
			    	<thead>
			    		<tr>
			    			<th>NO</th>
			    			<th>NAMA MAHASISWA</th>
			    			<th>PELAJARAN</th>
			    			<th>DOSEN</th>
			    			<th>TANGGAL</th>
			    		</tr>
			    	</thead>
			    		<tbody>
			    			<?php foreach ($ambil_matakuliah as $ambil):?>
			    			<?php $no=1; ?>
			    			<tr>
			    				<td><?=$no++; ?></td>
			    				<td><?= $ambil['mahasiswa'] ?></td>
			    				<td><?= $ambil['id_pelajaran'] ?></td>
			    				<td><?= $ambil['nama'] ?></td>
			    				<td><?= $ambil['tanggal'] ?></td>
			    			</tr>
			    		<?php endforeach; ?>
			    		</tbody>
			    </table>
			    <td><a href="<?= site_url('materi/materi/index') ?>" class="badge badge-warning">Kembali</a></td>
			  </div>
			</div>
		</div>
		
	</div>
</div>