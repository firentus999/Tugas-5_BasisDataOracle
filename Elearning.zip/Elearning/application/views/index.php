<div class="container-fluid">
  <nav class="navbar navbar-expand-lg bg-dark">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <a class="navbar-brand text-white" href="#" ><span id="navbar-brand">UNIVERSITAS PELITA BANGSA</span></a>
    <ul class="navbar-nav ml-auto mt-2 mt-lg-0 mr-5">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#about">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#footer">Footer</a>
      </li>
      <li class="nav-item">
        <a class="nav-link btn btn-primary" href="<?= site_url('login/login') ?>">Login</a>
      </li>
    </ul>
  </div>
</nav>

<div class="jumbotron jumbotron-fluid">
  <div class="container">
    <h1 class="display-4">Get work done <b>faster</b><br>and <b>better</b> with us</h1>
    <a href="" class="btn btn-primary">Our work</a>
  </div>
</div>

<div class="row justify-content-center">
  <div class="col-10 info-panel">
    <div class="row text-dark">
      <div class="col-lg">
        <img src="<?= site_url('assets/image/24.png') ?>" alt="" class="float-left">
        <h4>24 hours</h4>
        <p>Lorem ipsum dolor sit amet.</p>
      </div>
      <div class="col-lg">
          <img src="<?= site_url('assets/image/png.jpg') ?>" alt="" class="float-left">
          <h4>Document</h4>
          <p>Lorem ipsum dolor sit amet.</p>
      </div>
      <div class="col-lg">
          <img src="<?= site_url('assets/image/security.jpeg') ?>" alt="" class="float-left">
          <h4>Security</h4>
          <p>Lorem ipsum dolor sit amet.</p>
      </div>
    </div>
  </div>
</div>
<div id="about">
  <h4 class="text-center mt-5">About</h4>
  <div class="row justify-content-center">
    <div class="col-lg">
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Expedita, quibusdam beatae officia rem ducimus. Quod, et amet ipsam ullam magni cupiditate facilis deleniti minima possimus officia delectus tenetur cumque est.
    </div>
    <div class="col-lg">
      Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repellendus aperiam, facere hic beatae esse ad veniam. Tempore dolorem iste ratione fugiat, possimus ullam corrupti quibusdam consequatur dolores aperiam pariatur, optio!
    </div>
  </div> 
</div>

<div id="footer">
<footer class=" bg-dark text-white">
    <div class="container">
        <div class="row mt-4">
            <div class="col-sm">
                <h5>LAYANAN</h5>
                <ul class="list-group">
                  <li>Cras justo odio</li>
                  <li>Dapibus ac facilisis in</li>
                  <li>Morbi leo risus</li>
                  <li>Porta ac consectetur ac</li>
                  <li>Vestibulum at eros</li>
                </ul>
            </div>
            <div class="col-sm">
                <h5>ABOUT ME</h5>
                <ul class="list-group">
                  <li>Cras justo odio</li>
                  <li>Dapibus ac facilisis in</li>
                  <li>Morbi leo risus</li>
                  <li>Porta ac consectetur ac</li>
                  <li>Vestibulum at eros</li>
                </ul>
            </div>
            <div class="col-sm">
                <h5>CONTACT US</h5>
                <ul class="list-group">
                  <li>Cras justo odio</li>
                  <li>Dapibus ac facilisis in</li>
                  <li>Morbi leo risus</li>
                  <li>Porta ac consectetur ac</li>
                  <li>Vestibulum at eros</li>
                </ul>
            </div>
            <div class="col-sm">
                <h5>KOMENTAR</h5>
                <form>
                  <div class="form-group">
                    <input type="email" class="form-control" placeholder="Masukan Email">
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" placeholder="Masukan Nama">
                  </div>
                    <div class="form-group">
                    <input type="text" class="form-control text-area" placeholder="Komentar">
                  </div>
                     <button type="submit" class="btn btn-primary">Send</button>
                </form>
            </div>
        </div>
    </div>
</footer>
</div>
</div>