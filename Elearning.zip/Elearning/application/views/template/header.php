<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="<?= site_url('assets/vendor/css/bootstrap.min.css') ?>">
    <link rel="stylesheet" type="text/css" href="<?= site_url('assets/fontawesome/css/all.min.css')
    ?>">
	<link rel="stylesheet" type="text/css" href="<?= site_url('assets/style.css') ?>">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
