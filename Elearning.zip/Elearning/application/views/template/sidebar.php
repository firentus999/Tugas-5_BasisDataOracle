<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <a class="navbar-brand" href="<?= site_url('Tampilan') ?>"><h3><i class="fas fa-university"></i> Pelita Bangsa</h3></a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item <?php if($this->uri->segment(2)=='home'){
        echo 'active bg-warning font-weight-bold ';
      }elseif ($this->uri->segment(2)=='home'){
        echo 'active';
      }

       ?>">
        <a class="nav-link" href="<?= site_url('home/home/index') ?>">Home <span class="sr-only">(cur
        rent)</span></a>
      </li>

       <li class="nav-item <?php if($this->uri->segment(2)=='mahasiswa'){
        echo 'active bg-warning font-weight-bold ';
      }elseif ($this->uri->segment(2)=='mahasiswa'){
        echo 'active';
      }

       ?>">
        <a class="nav-link" href="<?= site_url('mahasiswa/mahasiswa/all') ?>">Mahasiswa <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item <?php if($this->uri->segment(2)=='pengajar'){
        echo 'active bg-warning font-weight-bold ';
      }elseif ($this->uri->segment(2)=='pengajar'){
        echo 'active';
      }

       ?>">
        <a class="nav-link" href="<?= site_url('pengajar/pengajar/index') ?>">Pengajar <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item <?php if($this->uri->segment(2)=='materi'){
        echo 'active bg-warning font-weight-bold ';
      }elseif ($this->uri->segment(2)=='materi'){
        echo 'active';
      }

       ?>">
        <a class="nav-link" href="<?= site_url('materi/materi/index') ?>">Materi <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?= site_url('login/login/logout') ?>" data-toggle="tooltip" data-placement="top" title="logout"><i class="fas fa-sign-out-alt"></i><span class="sr-only">(current)</span></a>
      </li>
    </ul>
  </div>
</nav>
