<?php 

/**
 * 
 */
class Tampilan extends CI_Controller
{
	
	public function index()
	{
		$this->load->view('template/header');
		$this->load->view('index.php');
		$this->load->view('template/footer');
	}
}


 ?>