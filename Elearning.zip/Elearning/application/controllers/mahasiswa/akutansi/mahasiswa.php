<?php

/**
 * 
 */
class Mahasiswa extends CI_Controller
{
	
	public function index()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}

		if($this->input->post('cari')){
			$data['keyword'] = $this->input->post('keyword');
		}else{
			$data['keyword'] = NULL;
		}

		$config['base_url'] = 'http://localhost:81/Elearning/mahasiswa/akutansi/mahasiswa/index';
		$config['total_rows'] = $this->db->count_all_results('tbl_mahasiswa');
		$config['per_page'] = 5;
		$data['start'] = $this->uri->segment(5);
		$this->pagination->initialize($config);

		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('nrp','Nrp','required','integer');
		$this->form_validation->set_rules('email','Email','required|valid_email');
		$this->form_validation->set_rules('jurusan','Jurusan','required');
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['jurusan'] = $this->uri->segment(2);
		$data['mahasiswa'] = $this->model_mahasiswa->getjurusan($config['per_page'],$data['start'],$data['keyword'],$data['jurusan'])->result_array();

		var_dump($data['mahasiswa']);die();
		$data['jurusan'] = $this->model_jurusan->getAllJurusan();
		if ($this->form_validation->run()==FALSE) {
				$this->load->view('template/header');
				$this->load->view('template/sidebar');
				$this->load->view('admin/akutansi/mahasiswa',$data);
				$this->load->view('template/footer');
	}else
	{

		$data['mahasiswa'] = $this->model_mahasiswa->ADD();
		if ($this->db->affected_rows()>0) {
			$this->session->set_flashdata('success', 'Ditambahkan');
		}
		redirect('mahasiswa/akutansi/mahasiswa');
	}
	}

	public function detailMahasiswa($id)
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['u_Mahasiswa'] = $this->model_mahasiswa->ubah($id);
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/akutansi/detail_mahasiswa',$data);
		$this->load->view('template/footer');
	}

	public function ubahMahasiswa($id)
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['jurusan'] = $this->model_jurusan->getAllJurusan();
		$data['u_Mahasiswa'] = $this->model_mahasiswa->ubah($id);
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/akutansi/ubah_mahasiswa',$data);
		$this->load->view('template/footer');
	}

	public function updateMahasiswa($id)
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
	
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('nrp','Nrp','required','integer');
		$this->form_validation->set_rules('email','Email','required|valid_email');
		$this->form_validation->set_rules('jurusan','Jurusan','required');
		$data['u_Mahasiswa'] = $this->model_mahasiswa->ubah($id);
		$data['jurusan'] = $this->model_jurusan->getAllJurusan();
		if ($this->form_validation->run()==FALSE) {
				$this->load->view('template/header');
				$this->load->view('template/sidebar');
				$this->load->view('admin/ubah_mahasiswa',$data);
				$this->load->view('template/footer');
	}else
	{

		$data['mahasiswa'] = $this->model_mahasiswa->UPDATE($id);
		if ($this->db->affected_rows()>0) {
			$this->session->set_flashdata('success', 'Diubah');
		}
		redirect('mahasiswa/akutansi/mahasiswa/index');
	}
}
	public function hapusMahasiswa($id)
	{
		$data['mahasiswa'] = $this->model_mahasiswa->DELETE($id);
		$data['mahasiswa'] = $this->model_mahasiswa->getAllMahasiswa();
			$this->session->set_flashdata('success', 'Dihapus');
		redirect('mahasiswa/akutansi/mahasiswa/index');
	}

}