<?php

/**
 * 
 */
class Registrasi extends CI_Controller
{
	
	public function index()
	{
		$this->form_validation->set_rules('role','Role','required|trim');
		$this->form_validation->set_rules('nama','Nama','required|trim');
		$this->form_validation->set_rules('email','Email','required|trim|valid_email|is_unique[tbl_login.email]');
		$this->form_validation->set_rules('password1','Password1','required|trim|min_length[3]|matches[password2]');
		$this->form_validation->set_rules('password2','Password2','required|trim|matches[password1]');

		if ($this->form_validation->run()==FALSE) {
				$this->load->view('template/header');
				$this->load->view('admin/registrasi/registrasi');
				$this->load->view('template/footer');
			}else{
				$this->model_login->registrasi();
				$this->session->set_flashdata('success','diTambahkan');
				redirect('login/login');
			}
	}
}