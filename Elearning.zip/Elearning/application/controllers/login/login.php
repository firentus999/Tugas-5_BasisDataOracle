<?php

/**
 * 
 */
class Login extends CI_Controller
{
    
    public function index()
    {
    	$this->form_validation->set_rules('email','Email','required|trim|valid_email');
    	$this->form_validation->set_rules('password','Password','required|trim');
    	if ($this->form_validation->run()==FALSE) {
		        $this->load->view('template/header');
		        $this->load->view('admin/registrasi/login');
		        $this->load->view('template/footer');	
    	 	}else{
    	 		$this->_login();
    	 	}
    }

    private function _login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$user = $this->db->get_where('tbl_login',['email' => $email])->row_array();
		if ($user) {
				if (password_verify($password, $user['password'])) {
					$data = [
								'email' => $user['email'],
								'role'	=> $user['role']
							];

							$this->session->set_flashdata('success','Masuk');
						$this->session->set_userdata($data);
						redirect('home/home');
				}else{
					$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Password Salah
													</div>');
					redirect('login/login');
			 	}
		}else{
				$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
												  Email Anda Salah
												</div>');
			 	redirect('login/login');
			 }
	}

	public function logout()
	{
		$this->session->unset_userdata('email');
		$this->session->set_flashdata('success','Logout');
		redirect('login/login');
	}
}