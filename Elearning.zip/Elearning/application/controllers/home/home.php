<?php

/**
 * 
 */
class Home extends CI_Controller
{
	
	public function index()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['user'] = $this->db->get_where('tbl_login',['email' => $this->session->userdata('email')])->row_array();
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/home',$data);
		$this->load->view('template/footer');
	}

	//dashboard
	public function allMahasiswa()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['allMahasiswa'] = $this->model_mahasiswa->getAllMahasiswa();
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/allMahasiswa',$data);
		$this->load->view('template/footer');
	}

	public function allPengajar()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['allPengajar'] = $this->model_pengajar->getPengajar();
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/allPengajar',$data);
		$this->load->view('template/footer');
	}
}