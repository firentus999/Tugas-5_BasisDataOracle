<?php  

/**
 * 
 */
class Materi extends CI_Controller
{
	
	public function index()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">');
					redirect('Login/login');
		}
                $data['cek']    = $this->db->get_where('tbl_login',['role'=>$this->session->userdata('role')])->row_array();
		$data['user'] = $this->db->get_where('tbl_login',['email' => $this->session->userdata('email')])->row_array();
		$data['pelajaran'] = $this->db->get('tbl_pelajaran')->result_array();
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/materi',$data);
		$this->load->view('template/footer');
	}

	public function cek_materi()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">');
					redirect('Login/login');
		}
		$data['user'] = $this->db->get_where('tbl_login',['email' => $this->session->userdata('email')])->row_array();
		$data['cek1'] = $this->db->get_where('tbl_ambil_pelajaran',['mahasiswa' => $data['user']['nama']])->row_array();

		$pelajaran = $this->uri->segment(4);
		$data['materi'] = $this->model_pelajaran->materi($pelajaran)->result_array();
		$data['pelajaran'] = $this->db->get('tbl_pelajaran')->result_array();
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/cek_materi',$data);
		$this->load->view('template/footer');
	}


	public function tambah_materi()
        {
                $config['upload_path']          = './materi/';
                $config['allowed_types']        = 'pdf|xls';
                $config['max_size']             = 20000;
                $config['max_width']            = 20000;
                $config['max_height']           = 20000;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('file'))
                {
                        echo "gagal Tambah";
                }
                else
                {
               
                        $materi 	= $this->upload->data();
                        $materi 	= $materi['file_name'];
                        $nama		= $this->input->post('nama',TRUE);
                        $tanggal	= date('Y-m-d H:I:S');
                        $mata_kuliah = $this->input->post('pelajaran',TRUE);

                        $data = [
                        			'id_materi' => '',
                        			'dosen'		=> $nama,
                        			'mata_kuliah'	=> $mata_kuliah,
                        			'materi'	=> $materi,
                        			'tanggal'	=> $tanggal
                        		];
                        $this->db->insert('tbl_materi',$data);
                        $this->session->set_flashdata('success','Upload');

                        redirect('materi/materi');
                }
        }

        public function hapus_materi()
	{
		$this->db->where('id_materi',$this->uri->segment(4));
		$this->db->delete('tbl_materi');
		$this->session->set_flashdata('success','Hapus');
		redirect('materi/materi');

	}

	public function ambil_materi()
	{
        $nama		= $this->input->post('nama',TRUE);
        $tanggal	= date('Y-m-d h:i:s');
        $mata_kuliah = $this->input->post('pelajaran',TRUE);
        $dosen		= $this->db->get_where('tbl_pengajar',['pelajaran'=>$mata_kuliah])->row_array();

        $data = [
        			'id_ambil' => '',
        			'mahasiswa'		=> $nama,
        			'id_pelajaran'	=> $mata_kuliah,
        			'id_pengajar'	=> $dosen['id_pengajar'],
        			'tanggal'	=> $tanggal
        		];
        $this->db->insert('tbl_ambil_pelajaran',$data);
        $this->session->set_flashdata('success','Menambahkan');

        redirect('materi/materi');
	}


        public function mahasiswa_materi()
        {
                if (!$this->session->userdata('email')) {
                        $this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">');
                                        redirect('Login/login');
                }
                $data['user'] = $this->db->get_where('tbl_login',['email' => $this->session->userdata('email')])->row_array();
                $data['ambil_matakuliah'] = $this->model_pelajaran->ambil_matakuliah()->result_array();
                $this->load->view('template/header');
                $this->load->view('template/sidebar');
                $this->load->view('admin/ambil_matakuliah',$data);
                $this->load->view('template/footer');
        }


        public function Excel_materi()
        {
                
                if ($this->input->post('cari')) {
                        $data['keyword'] = $this->input->post('keyword');
                }else{
                        $data['keyword'] = NULL;
                }

                $config['base_url'] = 'http://localhost/Elearning/pengajar/pengajar/index';
                $config['total_rows'] = $this->db->count_all_results('tbl_ambil_pelajaran');
                $config['per_page'] = 5;
                $data['start'] = $this->uri->segment(4);

                $this->pagination->initialize($config);
                $data['ambil_matakuliah'] = $this->model_pelajaran->ambil_matakuliah()->result_array();

                        $this->load->view('template/header');
                        $this->load->view('template/sidebar');
                        $this->load->view('admin/excel_materi',$data);
                        $this->load->view('template/footer');
                }

                public function Print_materi()
        {
                
                if ($this->input->post('cari')) {
                        $data['keyword'] = $this->input->post('keyword');
                }else{
                        $data['keyword'] = NULL;
                }

                $config['base_url'] = 'http://localhost/Elearning/pengajar/pengajar/index';
                $config['total_rows'] = $this->db->count_all_results('tbl_pengajar');
                $config['per_page'] = 5;
                $data['start'] = $this->uri->segment(4);

                $this->pagination->initialize($config);
                $data['ambil_matakuliah'] = $this->model_pelajaran->ambil_matakuliah()->result_array();
                        $this->load->view('template/header');
                        $this->load->view('template/sidebar');
                        $this->load->view('admin/print_materi',$data);
                        $this->load->view('template/footer');
                }


                public function lakukan_download()
                {  

                         if ($this->uri->segment(4)) {
                            $materi = $this->uri->segment(4);

                            $back_dir    ="materi/";
                            $file = $back_dir.$this->uri->segment(4);
                             
                                if (file_exists($file)) {
                                    header('Content-Description: File Transfer');
                                    header('Content-Type: application/octet-stream');
                                    header('Content-Disposition: attachment; filename='.basename($file));
                                    header('Content-Transfer-Encoding: binary');
                                    header('Expires: 0');
                                    header('Cache-Control: private');
                                    header('Pragma: private');
                                    header('Content-Length: ' . filesize($file));
                                    ob_clean();
                                    flush();
                                    readfile($file);
                                    
                                    exit;
                                } 
                                else {
                                    echo "GAGAL DOWLOAD";
                                }
                            }
                } 


    public function Excel_mahasiswa()
    {
        
        if ($this->input->post('cari')) {
            $data['keyword'] = $this->input->post('keyword');
        }else{
            $data['keyword'] = NULL;
        }

        $config['total_rows'] = $this->db->count_all_results('tbl_pengajar');
        $config['per_page'] = 5;
        $data['start'] = $this->uri->segment(4);

        $this->pagination->initialize($config);
        $data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
        $data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
        $data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
        $data['pengajar'] = $this->model_pengajar->getAllPengajar($config['per_page'],$data['start'],$data['keyword']);

            $this->load->view('template/header');
            $this->load->view('admin/pengajar/Excel_mahasiswa',$data);
            $this->load->view('template/footer');
        }

        public function Print_pengajar()
    {
        
        if ($this->input->post('cari')) {
            $data['keyword'] = $this->input->post('keyword');
        }else{
            $data['keyword'] = NULL;
        }
        $config['total_rows'] = $this->db->count_all_results('tbl_pengajar');
        $config['per_page'] = 5;
        $data['start'] = $this->uri->segment(4);

        $this->pagination->initialize($config);
        $data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
        $data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
        $data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
        $data['pengajar'] = $this->model_pengajar->getAllPengajar($config['per_page'],$data['start'],$data['keyword']);

            $this->load->view('template/header');
            $this->load->view('admin/pengajar/print_mahasiswa',$data);
            $this->load->view('template/footer');
        }      


}


?>