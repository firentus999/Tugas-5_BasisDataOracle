<?php

/**
 * 
 */
class Pengajar extends CI_Controller
{
	
	public function index()
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}


		if ($this->input->post('cari')) {
			$data['keyword'] = $this->input->post('keyword');
		}else{
			$data['keyword'] = NULL;
		}

		$config['base_url'] = 'http://localhost/Crud_Mahasiswa/pengajar/pengajar/index';
		$config['total_rows'] = $this->db->count_all_results('tbl_pengajar');
		$config['per_page'] = 5;
		$data['start'] = $this->uri->segment(4);

		$this->pagination->initialize($config);
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('nip','Nip','required','integer');
		$this->form_validation->set_rules('email','Email','required|valid_email');
		$this->form_validation->set_rules('pelajaran','Pelajaran','required');
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
		$data['pengajar'] = $this->model_pengajar->getAllPengajar($config['per_page'],$data['start'],$data['keyword']);
		$data['cek']	= $this->db->get_where('tbl_login',['role'=>$this->session->userdata('role')])->row_array();
		if($this->form_validation->run()== FALSE)
		{
			$this->load->view('template/header');
			$this->load->view('template/sidebar');
			$this->load->view('admin/pengajar/pengajar',$data);
			$this->load->view('template/footer');
		}else{
			$this->model_pengajar->ADD();
			if ($this->db->affected_rows() >0) {
				$this->session->set_flashdata('success','ditambahkan');
				redirect('pengajar/pengajar');
			}
		}

	}

	public function Excel_pengajar()
	{
		
		if ($this->input->post('cari')) {
			$data['keyword'] = $this->input->post('keyword');
		}else{
			$data['keyword'] = NULL;
		}

		$config['base_url'] = 'http://localhost/Crud_Mahasiswa/pengajar/pengajar/index';
		$config['total_rows'] = $this->db->count_all_results('tbl_pengajar');
		$config['per_page'] = 5;
		$data['start'] = $this->uri->segment(4);

		$this->pagination->initialize($config);
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
		$data['pengajar'] = $this->model_pengajar->getAllPengajar($config['per_page'],$data['start'],$data['keyword']);

			$this->load->view('template/header');
			$this->load->view('admin/pengajar/excel_pengajar',$data);
			$this->load->view('template/footer');
		}

		public function Print_pengajar()
	{
		
		if ($this->input->post('cari')) {
			$data['keyword'] = $this->input->post('keyword');
		}else{
			$data['keyword'] = NULL;
		}
		$config['total_rows'] = $this->db->count_all_results('tbl_pengajar');
		$config['per_page'] = 5;
		$data['start'] = $this->uri->segment(4);

		$this->pagination->initialize($config);
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
		$data['pengajar'] = $this->model_pengajar->getAllPengajar($config['per_page'],$data['start'],$data['keyword']);

			$this->load->view('template/header');
			$this->load->view('admin/pengajar/print_pengajar',$data);
			$this->load->view('template/footer');
		}


	public function detailPengajar($id)
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['u_Pengajar'] = $this->model_pengajar->ubah($id);
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/pengajar/detail_pengajar',$data);
		$this->load->view('template/footer');
	}

	public function ubahPengajar($id)
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
		$data['u_Pengajar'] = $this->model_pengajar->ubah($id);
		$this->load->view('template/header');
		$this->load->view('template/sidebar');
		$this->load->view('admin/pengajar/ubah_pengajar',$data);
		$this->load->view('template/footer');
	}

	public function updatePengajar($id)
	{
		if (!$this->session->userdata('email')) {
			$this->session->set_flashdata('wrong','<div class="alert alert-danger text-center" role="alert">
													  Silahkan Login Terlebih Dahulu
													</div>');
					redirect('Login/login');
		}
	
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('nip','Nip','required','integer');
		$this->form_validation->set_rules('email','Email','required|valid_email');
		$this->form_validation->set_rules('pelajaran','Pelajaran','required');
		$data['Pengajar'] = $this->db->count_all_results('tbl_pengajar');
		$data['Mahasiswa'] = $this->db->count_all_results('tbl_mahasiswa');
		$data['u_Pengajar'] = $this->model_pengajar->ubah($id);
		$data['pelajaran'] = $this->model_pelajaran->getAllPelajaran();
		if ($this->form_validation->run()==FALSE) {
				$this->load->view('template/header');
				$this->load->view('template/sidebar');
				$this->load->view('admin/ubah_pengajar',$data);
				$this->load->view('template/footer');
	}else
	{

		$data['pengajar'] = $this->model_pengajar->UPDATE($id);
		if ($this->db->affected_rows()>0) {
			$this->session->set_flashdata('success', 'Diubah');
		}
		redirect('pengajar/pengajar/index');
	}
}
	public function hapusPengajar($id)
	{
		$data['pengajar'] = $this->model_pengajar->DELETE($id);
		$data['pengajar'] = $this->model_pengajar->getAllPengajar();
			$this->session->set_flashdata('success', 'Dihapus');
		redirect('pengajar/pengajar/index');
	}

}