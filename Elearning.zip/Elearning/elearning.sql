-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 15, 2022 at 09:11 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.1.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elearning`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ambil_pelajaran`
--

CREATE TABLE `tbl_ambil_pelajaran` (
  `id_ambil` int(11) NOT NULL,
  `mahasiswa` varchar(50) NOT NULL,
  `id_pelajaran` varchar(50) NOT NULL,
  `id_dosen` int(5) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ambil_pelajaran`
--

INSERT INTO `tbl_ambil_pelajaran` (`id_ambil`, `mahasiswa`, `id_pelajaran`, `id_dosen`, `tanggal`) VALUES
(1, 'Nanda', 'Bahasa_Inggris', 2, '2022-01-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jurusan`
--

CREATE TABLE `tbl_jurusan` (
  `id_jurusan` int(11) NOT NULL,
  `kejuruan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_jurusan`
--

INSERT INTO `tbl_jurusan` (`id_jurusan`, `kejuruan`) VALUES
(1, 'Teknik Informatika'),
(2, '\r\nTeknik Mesin'),
(3, 'Management'),
(4, 'Akutansi'),
(5, 'Teknik Lingkungan');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id` int(11) NOT NULL,
  `role` int(1) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tanggal_join` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_login`
--

INSERT INTO `tbl_login` (`id`, `role`, `nama`, `gambar`, `email`, `password`, `tanggal_join`) VALUES
(9, 1, 'Admin', 'default.jpg', 'admin@gmail.com', '$2y$10$h95N7l8mKPwswR3CGJWUS.ELzOohxvgdfMTVVyVknF/4AxwefTLXO', '2022-01-15'),
(10, 2, 'Nanda', 'default.jpg', 'nanda@gmail.com', '$2y$10$qCfKmbWxHFJPKQyVzfZGiuFlX16fNb3vyw1Q.WO3jp/hukXYA3E3e', '2022-01-15'),
(11, 3, 'dodi', 'default.jpg', 'dodi@gmail.com', '$2y$10$M7CokwOex0NCVdYqebsfHuRNZdf7VE3eQfZAMMvTsLk10cJfLkpFO', '2022-01-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mahasiswa`
--

CREATE TABLE `tbl_mahasiswa` (
  `id` int(11) NOT NULL,
  `role` int(1) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nrp` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `jurusan` int(2) NOT NULL,
  `angkatan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mahasiswa`
--

INSERT INTO `tbl_mahasiswa` (`id`, `role`, `nama`, `nrp`, `email`, `jurusan`, `angkatan`) VALUES
(17, 2, 'agus', 311810099, 'firentua@gmail.com', 1, '2020'),
(18, 2, 'fahri', 311819900, 'fahri@gmail.com', 1, '2020'),
(19, 2, 'tina', 1181997777, 'tina@gmail.com', 3, '2021'),
(20, 2, 'dayu', 211113, 'dayu@gmail.com', 4, '2021'),
(21, 2, 'nina', 211121212, 'nina@gmail.com', 5, '2021'),
(22, 2, 'susi', 2147483647, 'susi@gmail.com', 1, '2020'),
(23, 2, 'ega', 311171888, 'ega@gmail.com', 2, '2020'),
(24, 2, 'lala', 1111171888, 'lala@gmail.com', 2, '2021');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_materi`
--

CREATE TABLE `tbl_materi` (
  `id_materi` int(11) NOT NULL,
  `dosen` varchar(50) NOT NULL,
  `mata_kuliah` varchar(50) NOT NULL,
  `materi` varchar(150) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_materi`
--

INSERT INTO `tbl_materi` (`id_materi`, `dosen`, `mata_kuliah`, `materi`, `tanggal`) VALUES
(3, 'dodi', '1', 'SO9497_10_SAP_char_(1).pdf', '2022-01-15');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pelajaran`
--

CREATE TABLE `tbl_pelajaran` (
  `id` int(11) NOT NULL,
  `pelajaran` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pelajaran`
--

INSERT INTO `tbl_pelajaran` (`id`, `pelajaran`) VALUES
(1, 'Bahasa_Inggris'),
(2, 'Matematika'),
(3, 'Bahasa_Jepang'),
(4, 'Pemograman'),
(5, 'Desain_Grafis'),
(6, 'Jaringan'),
(7, 'Akutansi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengajar`
--

CREATE TABLE `tbl_pengajar` (
  `id_pengajar` int(11) NOT NULL,
  `role` int(1) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nip` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pelajaran` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pengajar`
--

INSERT INTO `tbl_pengajar` (`id_pengajar`, `role`, `nama`, `nip`, `email`, `pelajaran`) VALUES
(2, 3, 'dodi', 118199999, 'dodo@gmail.com', 1),
(3, 3, 'sugih', 311819999, 'sugih@gmail.com', 2),
(4, 3, 'david', 118199977, 'david@gmail.com', 3),
(5, 3, 'dikdik', 2147483647, 'didik@gmail.com', 4),
(6, 3, 'dani', 33222222, 'dani@gmail.com', 5),
(7, 3, 'diki', 3322223, 'diki@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_role`
--

CREATE TABLE `tbl_role` (
  `id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_role`
--

INSERT INTO `tbl_role` (`id`, `role`) VALUES
(1, 'admin'),
(2, 'mahasiswa'),
(3, 'pengajar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_ambil_pelajaran`
--
ALTER TABLE `tbl_ambil_pelajaran`
  ADD PRIMARY KEY (`id_ambil`);

--
-- Indexes for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  ADD PRIMARY KEY (`id_jurusan`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_materi`
--
ALTER TABLE `tbl_materi`
  ADD PRIMARY KEY (`id_materi`);

--
-- Indexes for table `tbl_pelajaran`
--
ALTER TABLE `tbl_pelajaran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pengajar`
--
ALTER TABLE `tbl_pengajar`
  ADD PRIMARY KEY (`id_pengajar`);

--
-- Indexes for table `tbl_role`
--
ALTER TABLE `tbl_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_ambil_pelajaran`
--
ALTER TABLE `tbl_ambil_pelajaran`
  MODIFY `id_ambil` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  MODIFY `id_jurusan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_materi`
--
ALTER TABLE `tbl_materi`
  MODIFY `id_materi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_pelajaran`
--
ALTER TABLE `tbl_pelajaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_pengajar`
--
ALTER TABLE `tbl_pengajar`
  MODIFY `id_pengajar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_role`
--
ALTER TABLE `tbl_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
